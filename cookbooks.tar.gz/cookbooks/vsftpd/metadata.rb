maintainer       "Robert J. Berger"
maintainer_email "rberger+maintainer@ibd.com"
license          "Apache License, Version 2.0"
description      "Installs/Configures vsftpd for Secure SSL SFTP"
long_description IO.read(File.join(File.dirname(__FILE__), 'README.rdoc'))
version          "0.0.1"
